package com.task.managment.ui_web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UiWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(UiWebApplication.class, args);
	}

}
