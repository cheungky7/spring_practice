package com.task.managment.ui_web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UiWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
